#!/bin/bash

clear

if [[ $EUID -ne 0 ]]; then
    echo "You must be a root user to install files in /usr/local/aquapi/" 2>&1
    echo "Please use sudo:"
    echo ""
    echo "----------------"
    echo "sudo $0"
    echo "----------------"
    echo ""
    echo "Press \"Enter\" to compile without install or CTRL+C to break." 2>&1
    read -s -n 1 key
    if [[ $key = "" ]]; then 
        cd Debug
        make clean
        make all
    else
        exit 1
    fi


else
    cd Debug
    make clean
    make all
    make install
fi


